"use client"

import { useState, useEffect } from "react"
import { Menu, X } from "lucide-react"
import { cn } from "@/lib/utils"
// import Link from "next/link" // Replaced with next-intl Link? Or just use next/link with locale
// If using next-intl router, we might want to use the Link provided by them or handle locale manually.
// For now, let's stick to next/link but assume we need to prepend locale or use a wrapper.
// Since we have middleware, standard Links might need the locale prefix if not automatically handled by next-intl's Link.
// Let's us next/link for now and if we need the `Link` from `navigation.ts` (if we created one) we'd use that.
// We haven't created a `navigation.ts` which is common in next-intl setups.
// I'll stick to `next/link` but keep in mind links might need to be dynamic. 
// Actually, `next-intl` usually encourages a `navigation.ts` wrapper.
// I'll stick to a simple `Link` for now, maybe `Link href={/}` will be redirected by middleware to `/en/`.
import Link from "next/link"

import { useTranslations } from "next-intl"

export default function Header() {
    const [scrolled, setScrolled] = useState(false)
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
    const [mounted, setMounted] = useState(false)
    const t = useTranslations("Public.Landing.Navigation")
    const tCommon = useTranslations("Common")

    useEffect(() => {
        setMounted(true)
        const handleScroll = () => {
            setScrolled(window.scrollY > 50)
        }
        window.addEventListener("scroll", handleScroll)
        return () => window.removeEventListener("scroll", handleScroll)
    }, [])

    const navItems = [
        { name: t("About"), href: "#about" },
        { name: t("Benefits"), href: "#benefits" },
        { name: t("Contact"), href: "#contact" },
    ]

    return (
        <nav
            className={cn(
                "fixed z-50 left-1/2 -translate-x-1/2 transition-all duration-500 ease-in-out",
                scrolled
                    ? "top-14 w-[98%] max-w-5xl rounded-full bg-background/80 backdrop-blur-md border border-border/40 py-2 px-2 shadow-sm dark:shadow-[0_0_20px_rgba(0,0,0,0.5)]"
                    : "top-8 w-full bg-transparent py-4 border-b border-transparent"
            )}
        >
            <div
                className={cn(
                    "flex items-center justify-between transition-all duration-500",
                    scrolled ? "gap-4 md:gap-6" : "max-w-7xl mx-auto w-full px-6"
                )}
            >
                <div className="flex items-center gap-2">
                    <Link href="/" className="flex items-center gap-2 transition-all duration-500 hover:scale-105">
                        <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center font-bold text-lg text-primary-foreground">ETC</div>
                        <span className={cn("hidden sm:inline font-bold text-lg", scrolled ? "text-foreground" : "text-primary-foreground")}>Electronic Toll Collection</span>
                    </Link>
                </div>

                <div className="flex items-center gap-4 lg:gap-8">
                    {/* Desktop Nav */}
                    <div className="hidden md:flex items-center gap-4 lg:gap-8">
                        {navItems.map((item) => (
                            <Link
                                key={item.name}
                                href={item.href}
                                className={cn(
                                    "text-sm font-medium transition-colors uppercase tracking-wide whitespace-nowrap",
                                    scrolled ? "text-foreground/80 hover:text-accent" : "text-primary-foreground/80 hover:text-white"
                                )}
                            >
                                {item.name}
                            </Link>
                        ))}
                    </div>

                    <div className="hidden md:flex gap-2">
                        <Link
                            href="/login"
                            className={cn(
                                "px-6 py-2 rounded-full font-bold text-sm transition-all duration-300 shadow-[0_0_20px_rgba(255,255,255,0.3)] whitespace-nowrap",
                                scrolled
                                    ? "bg-foreground text-background hover:bg-accent hover:text-white hover:shadow-[0_0_20px_rgba(232,154,92,0.5)]"
                                    : "bg-white/10 backdrop-blur-sm border border-white/20 text-white hover:bg-white/20"
                            )}
                        >
                            {tCommon("Login")}
                        </Link>
                        <Link
                            href="/register"
                            className="px-6 py-2 rounded-full bg-accent text-white font-bold text-sm hover:bg-accent/90 transition-all duration-300 shadow-lg whitespace-nowrap"
                        >
                            {tCommon("Register")}
                        </Link>
                    </div>


                    {/* Mobile Menu Toggle */}
                    <button
                        className={cn("md:hidden transition-colors", scrolled ? "text-foreground" : "text-primary-foreground")}
                        onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                    >
                        {mobileMenuOpen ? <X /> : <Menu />}
                    </button>
                </div>
            </div>

            {/* Mobile Menu */}
            <div
                className={cn(
                    "md:hidden absolute left-0 right-0 bg-background/95 backdrop-blur-xl border-b border-border/10 transition-all duration-300 overflow-hidden rounded-b-2xl",
                    mobileMenuOpen ? "max-h-96 py-6 top-full mt-2" : "max-h-0 top-full"
                )}
            >
                <div className="flex flex-col items-center gap-6">
                    {navItems.map((item) => (
                        <Link
                            key={item.href}
                            href={item.href}
                            className="text-lg font-medium text-foreground/80 hover:text-accent transition-colors"
                            onClick={() => setMobileMenuOpen(false)}
                        >
                            {item.name}
                        </Link>
                    ))}
                    <div className="flex flex-col gap-4 w-full px-8">
                        <Link
                            href="/login"
                            className="w-full text-center px-8 py-3 rounded-full bg-foreground text-background font-bold hover:bg-accent hover:text-white transition-all duration-300"
                            onClick={() => setMobileMenuOpen(false)}
                        >
                            {tCommon("Login")}
                        </Link>
                        <Link
                            href="/register"
                            className="w-full text-center px-8 py-3 rounded-full bg-accent text-white font-bold hover:bg-accent/90 transition-all duration-300"
                            onClick={() => setMobileMenuOpen(false)}
                        >
                            {tCommon("Register")}
                        </Link>
                    </div>
                </div>
            </div>
        </nav>
    )
}
