"use client"

import { useTranslations } from "next-intl"

import { Button } from "@/components/ui/button"
import { ChevronRight } from "lucide-react"

export default function Hero() {
  const t = useTranslations("Public.Landing.Hero")

  return (
    <section className="relative w-full bg-gradient-to-b from-primary to-secondary overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          {/* Left Content */}
          <div className="text-primary-foreground space-y-6 animate-slide-in-left" style={{ animationDelay: "0.1s" }}>
            <div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight text-balance">
                {t("Title")}
              </h1>
            </div>
            <p className="text-lg md:text-xl text-primary-foreground/90">
              {t("Subtitle")}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button
                size="lg"
                className="bg-accent hover:bg-accent/90 text-white font-semibold flex items-center gap-2"
              >
                {t("GetStarted")} <ChevronRight size={20} />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10 font-semibold bg-transparent"
              >
                {t("LearnMore")}
              </Button>
            </div>
          </div>

          {/* Right Image */}
          <div
            className="hidden md:flex items-center justify-center animate-fade-in-up"
            style={{ animationDelay: "0.3s" }}
          >
            <img src="https://pub-4515856afb144f48b424b21c14a3d927.r2.dev/uploads/1768607974459-etc-img.png" alt="ETC Lane" className="w-full h-auto max-w-md rounded-lg shadow-2xl" />
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="flex flex-col items-center gap-2 text-primary-foreground/60">
          <span className="text-sm font-medium">{t("ScrollToExplore")}</span>
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
          </svg>
        </div>
      </div>
    </section>
  )
}
