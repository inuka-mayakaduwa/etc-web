"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { UserPlus, LogIn, MapPin } from "lucide-react"
import { useTranslations } from "next-intl"

export default function QuickActions() {
  const t = useTranslations("Public.Landing.QuickActions")

  const actions = [
    {
      key: "Register",
      icon: UserPlus,
      color: "text-accent",
    },
    {
      key: "Login",
      icon: LogIn,
      color: "text-secondary",
    },
    {
      key: "Track",
      icon: MapPin,
      color: "text-primary",
    },
  ]

  return (
    <section className="w-full py-16 md:py-24 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {actions.map((action, index) => {
            const Icon = action.icon
            return (
              <Card
                key={index}
                className="p-6 text-center hover:shadow-lg transition-all duration-300 border-2 border-border bg-card animate-fade-in-up"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="flex justify-center mb-4">
                  <Icon className={`w-12 h-12 ${action.color}`} />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-2">{t(`${action.key}.Title`)}</h3>
                <p className="text-foreground/70 mb-6">{t(`${action.key}.Description`)}</p>
                <Button className="w-full bg-accent hover:bg-accent/90 text-white font-semibold">
                  {t(`${action.key}.Button`)}
                </Button>
              </Card>
            )
          })}
        </div>
      </div>
    </section>
  )
}
